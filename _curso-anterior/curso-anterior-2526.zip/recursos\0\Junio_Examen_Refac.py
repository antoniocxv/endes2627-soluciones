texto = input("Introduce un texto: ")

palabras = texto.split()
palabras_sin_vacias = []

for aux in palabras:
    if aux != "":
        palabras_sin_vacias.append(aux)

print("Número de palabras:", len(palabras_sin_vacias))

frecuencias = {}

for temp in palabras_sin_vacias:
    palabra_limpia = temp.lower().strip(".,;:!?\"'")
    if palabra_limpia in frecuencias:
        frecuencias[palabra_limpia] += 1
    if palabra_limpia not in frecuencias:
        frecuencias[palabra_limpia] = 1

print("Frecuencia de palabras:")
for palabra in frecuencias:
    print(palabra, ":", frecuencias[palabra])
