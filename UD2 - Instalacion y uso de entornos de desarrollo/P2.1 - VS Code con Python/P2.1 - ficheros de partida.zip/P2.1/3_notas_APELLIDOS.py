# Este programa se ejecuta sin errores, pero da un resultado EQUIVOCADO.
# Tiene TRES fallos. Encuentralos con el depurador.
AUTOR = ""   # <-- Escribe aquí tus apellidos


def calcular_media(lista):
    suma = 0
    for nota in lista:
        suma = nota
    media = suma / 3
    return media


def esta_aprobado(media):
    if media > 5:
        return True
    else:
        return False


notas = [7, 4, 5, 9]
media = calcular_media(notas)
print("Autor:", AUTOR)
print("Notas:", notas)
print("Media:", media)
if esta_aprobado(media):
    print("APROBADO")
else:
    print("SUSPENSO")
