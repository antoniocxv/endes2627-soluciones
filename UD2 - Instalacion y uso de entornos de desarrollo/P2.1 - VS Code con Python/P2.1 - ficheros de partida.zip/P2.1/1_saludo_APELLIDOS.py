# Renombra este fichero poniendo tus apellidos:  1_saludo_perez_gomez.py
AUTOR = ""   # <-- Escribe aquí tus apellidos

print("Programa de:", AUTOR)
nombre = input("¿Cómo te llamas? ")
print("Encantado,", nombre)
