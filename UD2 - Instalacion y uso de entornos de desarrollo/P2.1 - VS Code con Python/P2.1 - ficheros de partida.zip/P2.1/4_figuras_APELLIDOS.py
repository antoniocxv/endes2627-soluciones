# Este fichero esta mal FORMATEADO a proposito. NO lo toques a mano:
# captura como esta ahora, guarda con Ctrl+S, y captura como queda.
AUTOR=""
import math
def area_circulo( radio ):
    resultado=math.pi*radio**2
    return resultado
def  area_rectangulo(base,altura):
        return base*altura
print( "Autor:",AUTOR )
print("Circulo:" ,area_circulo(3))
print("Rectangulo:",area_rectangulo( 4,5 ))
