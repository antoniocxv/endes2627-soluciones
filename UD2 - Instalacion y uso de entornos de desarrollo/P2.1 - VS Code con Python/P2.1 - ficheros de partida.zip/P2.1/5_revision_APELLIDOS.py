# En la lista hay UNA nota imposible. Encuentrala SIN LEER LA LISTA,
# con un punto de ruptura condicional.
AUTOR = ""   # <-- Escribe aquí tus apellidos

notas = [6, 7, 5, 8, 4, 9, 13, 6, 7, 5, 8, 4, 9, 6, 7]

print("Autor:", AUTOR)
contador = 0
for nota in notas:
    contador = contador + 1
    print("Alumno", contador, "->", nota)
