# ATENCION: este programa TIENE UN ERROR A PROPOSITO.
# Ejecutalo tal cual, captura el error, y despues corrigelo.
AUTOR = ""   # <-- Escribe aquí tus apellidos

print("Programa de:", AUTOR)
edad = input("¿Cuántos años tienes? ")
print("El año que viene tendrás", edad + 1)
